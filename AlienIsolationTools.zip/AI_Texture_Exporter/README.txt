This tool was created by Cra0kalo and modified by MattFiler to produce a more "user-friendly" version.

To use, just drop the exe into your Alien Isolation /ENV/DATA/ folder and run it.

Once the program is finished you will have a folder called "CONVERTED" containing all of the game's extracted textures.